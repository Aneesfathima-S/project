import { useCallback, useEffect, useState } from 'react';
import { setGlobalToastHandler } from '../api/axiosInstance';

interface ToastItem {
  id: number;
  message: string;
  variant: 'danger' | 'success' | 'info';
}

let pushToastExternal: ((message: string, variant?: ToastItem['variant']) => void) | null = null;

/** Call from anywhere to show a toast, without needing the component instance. */
export function pushToast(message: string, variant: ToastItem['variant'] = 'info') {
  pushToastExternal?.(message, variant);
}

/**
 * Renders a fixed-position stack of Bootstrap toasts. Also registers
 * itself as the axios instance's generic network/5xx error toast handler.
 */
export default function ToastHost() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const push = useCallback((message: string, variant: ToastItem['variant'] = 'info') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, variant }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 6000);
  }, []);

  useEffect(() => {
    pushToastExternal = push;
    setGlobalToastHandler((message) => push(message, 'danger'));
    return () => {
      pushToastExternal = null;
    };
  }, [push]);

  return (
    <div
      className="toast-container position-fixed bottom-0 end-0 p-3"
      style={{ zIndex: 1080 }}
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`toast show text-bg-${t.variant === 'info' ? 'dark' : t.variant} border-0`}
          role="alert"
        >
          <div className="d-flex">
            <div className="toast-body">{t.message}</div>
            <button
              type="button"
              className="btn-close btn-close-white me-2 m-auto"
              onClick={() => setToasts((prev) => prev.filter((x) => x.id !== t.id))}
              aria-label="Close"
            />
          </div>
        </div>
      ))}
    </div>
  );
}
