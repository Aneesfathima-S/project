import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function LandingPage() {
  const { isAuthenticated, role } = useAuth();

  return (
    <div className="text-center py-5">
      <h1 className="display-5 fw-bold mb-3">Policy Management System</h1>
      <p className="lead text-muted mb-4">
        Browse, search, and manage insurance policies — vehicle, travel, life, health, child, and
        retirement plans — all in one place.
      </p>

      {!isAuthenticated ? (
        <div className="d-flex justify-content-center gap-3">
          <Link to="/login" className="btn btn-primary btn-lg">
            Log In
          </Link>
          <Link to="/register" className="btn btn-outline-primary btn-lg">
            Register
          </Link>
        </div>
      ) : (
        <div className="d-flex justify-content-center gap-3">
          <Link to="/policies" className="btn btn-primary btn-lg">
            View Policies
          </Link>
          {role === 'ADMIN' && (
            <Link to="/admin/dashboard" className="btn btn-outline-primary btn-lg">
              Admin Dashboard
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
