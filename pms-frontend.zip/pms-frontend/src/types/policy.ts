import type { UserType } from './customer';

export type PolicyType =
  | 'VEHICLE_INSURANCE'
  | 'TRAVEL_INSURANCE'
  | 'LIFE_INSURANCE'
  | 'HEALTH_INSURANCE'
  | 'CHILD_PLANS'
  | 'RETIREMENT_PLANS';

export const POLICY_TYPE_LABELS: Record<PolicyType, string> = {
  VEHICLE_INSURANCE: 'Vehicle Insurance',
  TRAVEL_INSURANCE: 'Travel Insurance',
  LIFE_INSURANCE: 'Life Insurance',
  HEALTH_INSURANCE: 'Health Insurance',
  CHILD_PLANS: 'Child Plans',
  RETIREMENT_PLANS: 'Retirement Plans',
};

export const USER_TYPES: UserType[] = ['A', 'B', 'C', 'D', 'E'];

export interface PolicyRequestDTO {
  policyName: string;
  startDate: string; // yyyy-MM-dd
  durationYears: number;
  companyName: string;
  initialDeposit: number;
  policyType: PolicyType;
  userTypes: UserType[];
  termsPerYear: number;
  termAmount: number;
  interest: number;
}

export interface PolicyResponseDTO {
  policyId: string;
  policyName: string;
  startDate: string;
  endDate: string;
  durationYears: number;
  companyName: string;
  initialDeposit: number;
  policyType: PolicyType;
  userTypes: UserType[];
  termsPerYear: number;
  termAmount: number;
  interest: number;
  maturityAmount: number;
  confirmationMessage: string;
}

export interface PolicyPageResponseDTO {
  policies: PolicyResponseDTO[];
  currentPage: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  sortBy: string;
  sortDirection: string;
}

export interface SearchResponseDTO {
  message: string;
  policies: PolicyResponseDTO[];
  currentPage: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
}

export interface PolicySearchParams {
  policyType?: PolicyType;
  years?: number;
  companyName?: string;
  policyId?: string;
  policyName?: string;
  page?: number;
  size?: number;
  sort?: string;
}
