import type { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import type { Role } from '../types/auth';
import LoadingSpinner from '../components/LoadingSpinner';

interface ProtectedRouteProps {
  roles?: Role[];
  children: ReactNode;
}

/**
 * Guards a route so that:
 *  - unauthenticated users are redirected to /login
 *  - authenticated users whose role isn't in `roles` are redirected to /unauthorized
 *  - everyone else sees the wrapped page
 *
 * Omit `roles` to allow any authenticated user (admin or customer).
 */
export default function ProtectedRoute({ roles, children }: ProtectedRouteProps) {
  const { isAuthenticated, isInitializing, role } = useAuth();
  const location = useLocation();

  if (isInitializing) {
    return <LoadingSpinner />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (roles && roles.length > 0 && (!role || !roles.includes(role))) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
}
