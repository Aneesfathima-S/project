import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function Navbar() {
  const { isAuthenticated, role, user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `nav-link${isActive ? ' active fw-semibold' : ''}`;

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
      <div className="container">
        <NavLink className="navbar-brand fw-bold" to="/">
          PMS
        </NavLink>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#mainNavbar"
          aria-controls="mainNavbar"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="mainNavbar">
          <ul className="navbar-nav ms-auto align-items-lg-center gap-1">
            {isAuthenticated && (
              <>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/policies">
                    Policies
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/policies/search">
                    Search
                  </NavLink>
                </li>
              </>
            )}
            {isAuthenticated && role === 'ADMIN' && (
              <>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/admin/dashboard">
                    Admin
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/admin/policies/new">
                    New Policy
                  </NavLink>
                </li>
              </>
            )}
            {!isAuthenticated && (
              <>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/login">
                    Login
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className={linkClass} to="/register">
                    Register
                  </NavLink>
                </li>
              </>
            )}
            {isAuthenticated && (
              <li className="nav-item d-flex align-items-center gap-2 ms-lg-3">
                <span className="badge text-bg-light text-primary">
                  {user?.username} · {role}
                </span>
                <button
                  type="button"
                  className="btn btn-outline-light btn-sm"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}
