# Policy Management System — Frontend

React 18 + Vite + TypeScript frontend for the Policy Management System, talking to the
Spring Boot microservices through the API Gateway at `http://localhost:8092`.

## Stack

- React 18 + Vite + TypeScript
- Bootstrap 5 (global CSS/JS, no Tailwind/MUI)
- React Router v6
- Axios with a JWT request/response interceptor
- Context API for auth state
- react-hook-form for client-side validation

## Getting started

```bash
npm install
npm run dev
```

The app runs at `http://localhost:5173` by default (see `vite.config.ts`).

Make sure the backend (service-registry, api-gateway, auth-service, customer-service,
policy-service) is up and the gateway is reachable at the URL configured in `.env`:

```
VITE_API_BASE_URL=http://localhost:8092
```

## Project structure

```
src/
  api/            axios instance (JWT interceptor) + one module per backend service
  auth/           AuthContext (login/logout/auto-logout) + ProtectedRoute
  components/     Navbar, PolicyTable, PaginationBar, LoadingSpinner, ErrorAlert, ToastHost
  pages/          one component per route (see below)
  types/          TypeScript interfaces mirroring every backend DTO
  utils/          INR currency / date formatting helpers
```

## Routes

| Route                     | Access          | Purpose                                   |
|---------------------------|-----------------|--------------------------------------------|
| `/`                       | public          | Landing page                               |
| `/login`                  | public          | Customer/Admin login (role toggle)         |
| `/register`                | public          | Customer self-registration                 |
| `/policies`                | ADMIN + CUSTOMER| Paginated list of all policies             |
| `/policies/search`         | ADMIN + CUSTOMER| Search form + results                      |
| `/admin/policies/new`      | ADMIN only      | Policy registration form                   |
| `/admin/dashboard`         | ADMIN only      | Summary + quick links                      |
| `/unauthorized`            | public          | Shown on role mismatch                     |
| `*`                        | public          | 404                                        |

## Auth notes

- On login, the JWT is decoded client-side (`jwt-decode`) to read the `sub` (username) and
  `role` claims — there is no `/me` endpoint.
- The token is kept in memory (`AuthContext`) and mirrored to `localStorage` so a page refresh
  doesn't log the user out (as long as the token hasn't expired).
- A timer scheduled from the token's `exp` claim automatically logs the user out and redirects
  to `/login` when the token expires — checked once on app load and again via the timer.
- The axios response interceptor clears auth state and redirects to `/login` on any `401`, and
  shows a generic toast on network errors or `5xx` responses.

## Notes

- This project was scaffolded without running `npm install` in the environment that generated
  it (no network access), so dependency versions in `package.json` haven't been resolved/locked
  here — run `npm install` yourself to generate `package-lock.json` and verify everything builds.
