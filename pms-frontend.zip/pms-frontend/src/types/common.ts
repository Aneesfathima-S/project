/**
 * Shared error shape returned by any 4xx/5xx response from the
 * customer-service or policy-service (via the API gateway).
 */
export interface ErrorResponse {
  timestamp: string;
  status: number;
  error: string;
  message: string;
  path: string;
  details: string[];
}

/** Normalized error info our axios interceptor / callers work with. */
export interface ApiErrorInfo {
  message: string;
  details: string[];
  status?: number;
}
