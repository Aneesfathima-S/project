import { Link } from 'react-router-dom';

export default function UnauthorizedPage() {
  return (
    <div className="text-center py-5">
      <h1 className="display-4 fw-bold text-warning">403</h1>
      <p className="lead">You don&apos;t have permission to access this page.</p>
      <Link to="/" className="btn btn-primary mt-3">
        Back to Home
      </Link>
    </div>
  );
}
