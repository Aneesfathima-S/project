import type { ApiErrorInfo } from '../types/common';

interface ErrorAlertProps {
  error: ApiErrorInfo | string | null;
  onDismiss?: () => void;
}

export default function ErrorAlert({ error, onDismiss }: ErrorAlertProps) {
  if (!error) return null;

  const message = typeof error === 'string' ? error : error.message;
  const details = typeof error === 'string' ? [] : error.details;

  return (
    <div className="alert alert-danger" role="alert">
      <div className="d-flex justify-content-between align-items-start">
        <div>
          <div className="fw-semibold">{message}</div>
          {details.length > 0 && (
            <ul className="mb-0 mt-1 ps-3 small">
              {details.map((d, i) => (
                <li key={i}>{d}</li>
              ))}
            </ul>
          )}
        </div>
        {onDismiss && (
          <button
            type="button"
            className="btn-close"
            aria-label="Close"
            onClick={onDismiss}
          />
        )}
      </div>
    </div>
  );
}
