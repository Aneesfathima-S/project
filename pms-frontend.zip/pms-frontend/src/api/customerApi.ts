import axiosInstance from './axiosInstance';
import type { CustomerRequestDTO, CustomerResponseDTO } from '../types/customer';

export const customerApi = {
  register: (payload: CustomerRequestDTO) =>
    axiosInstance
      .post<CustomerResponseDTO>('/api/v1.0/customer/register', payload)
      .then((res) => res.data),
};
