import { Route, Routes } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext';
import ProtectedRoute from './auth/ProtectedRoute';
import Navbar from './components/Navbar';
import ToastHost from './components/ToastHost';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import PolicyListPage from './pages/PolicyListPage';
import PolicySearchPage from './pages/PolicySearchPage';
import PolicyRegisterPage from './pages/PolicyRegisterPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import UnauthorizedPage from './pages/UnauthorizedPage';
import NotFoundPage from './pages/NotFoundPage';

export default function App() {
  return (
    <AuthProvider>
      <Navbar />
      <main className="container py-4">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          <Route
            path="/policies"
            element={
              <ProtectedRoute roles={['ADMIN', 'CUSTOMER']}>
                <PolicyListPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/policies/search"
            element={
              <ProtectedRoute roles={['ADMIN', 'CUSTOMER']}>
                <PolicySearchPage />
              </ProtectedRoute>
            }
          />

          <Route
            path="/admin/policies/new"
            element={
              <ProtectedRoute roles={['ADMIN']}>
                <PolicyRegisterPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/dashboard"
            element={
              <ProtectedRoute roles={['ADMIN']}>
                <AdminDashboardPage />
              </ProtectedRoute>
            }
          />

          <Route path="/unauthorized" element={<UnauthorizedPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <ToastHost />
    </AuthProvider>
  );
}
