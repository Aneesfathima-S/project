import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { policyApi } from '../api/policyApi';
import { toApiErrorInfo } from '../api/axiosInstance';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorAlert from '../components/ErrorAlert';
import { useAuth } from '../auth/AuthContext';
import type { ApiErrorInfo } from '../types/common';

export default function AdminDashboardPage() {
  const { user } = useAuth();
  const [totalPolicies, setTotalPolicies] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiErrorInfo | null>(null);

  useEffect(() => {
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await policyApi.getAll(0, 1);
        setTotalPolicies(data.totalElements);
      } catch (err) {
        setError(toApiErrorInfo(err));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div>
      <h1 className="h3 mb-1">Admin Dashboard</h1>
      <p className="text-muted mb-4">Welcome back, {user?.username}.</p>

      <ErrorAlert error={error} onDismiss={() => setError(null)} />

      <div className="row g-4 mb-4">
        <div className="col-md-4">
          <div className="card shadow-sm h-100">
            <div className="card-body">
              <div className="text-muted small">Total Policies</div>
              {loading ? (
                <LoadingSpinner fullPage={false} label="" />
              ) : (
                <div className="display-6 fw-bold text-primary">{totalPolicies ?? '—'}</div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="row g-4">
        <div className="col-md-4">
          <Link to="/admin/policies/new" className="card text-decoration-none shadow-sm h-100">
            <div className="card-body">
              <h2 className="h5">Register a New Policy</h2>
              <p className="text-muted mb-0 small">Create a new insurance policy offering.</p>
            </div>
          </Link>
        </div>
        <div className="col-md-4">
          <Link to="/policies" className="card text-decoration-none shadow-sm h-100">
            <div className="card-body">
              <h2 className="h5">View All Policies</h2>
              <p className="text-muted mb-0 small">Browse the full paginated policy list.</p>
            </div>
          </Link>
        </div>
        <div className="col-md-4">
          <Link to="/policies/search" className="card text-decoration-none shadow-sm h-100">
            <div className="card-body">
              <h2 className="h5">Search Policies</h2>
              <p className="text-muted mb-0 small">Find policies by type, company, name, or ID.</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
