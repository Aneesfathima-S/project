import { useCallback, useEffect, useState } from 'react';
import { policyApi } from '../api/policyApi';
import { toApiErrorInfo } from '../api/axiosInstance';
import PolicyTable from '../components/PolicyTable';
import PaginationBar from '../components/PaginationBar';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorAlert from '../components/ErrorAlert';
import type { ApiErrorInfo } from '../types/common';
import type { PolicyPageResponseDTO } from '../types/policy';

const PAGE_SIZE = 10;

export default function PolicyListPage() {
  const [data, setData] = useState<PolicyPageResponseDTO | null>(null);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiErrorInfo | null>(null);

  const load = useCallback(async (targetPage: number) => {
    setLoading(true);
    setError(null);
    try {
      const response = await policyApi.getAll(targetPage, PAGE_SIZE);
      setData(response);
    } catch (err) {
      setError(toApiErrorInfo(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(page);
  }, [page, load]);

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1 className="h3 mb-0">All Policies</h1>
        {data && (
          <span className="text-muted small">
            {data.totalElements} total polic{data.totalElements === 1 ? 'y' : 'ies'}
          </span>
        )}
      </div>

      <ErrorAlert error={error} onDismiss={() => setError(null)} />

      {loading ? (
        <LoadingSpinner label="Loading policies…" />
      ) : (
        <>
          <div className="card shadow-sm">
            <div className="card-body">
              <PolicyTable policies={data?.policies ?? []} />
            </div>
          </div>
          <div className="mt-4">
            <PaginationBar
              currentPage={data?.currentPage ?? 0}
              totalPages={data?.totalPages ?? 0}
              onPageChange={setPage}
            />
          </div>
        </>
      )}
    </div>
  );
}
