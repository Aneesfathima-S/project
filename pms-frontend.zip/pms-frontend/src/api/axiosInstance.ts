import axios, { type AxiosError } from 'axios';
import type { ApiErrorInfo, ErrorResponse } from '../types/common';

const AUTH_TOKEN_KEY = 'pms_token';

const baseURL = import.meta.env.VITE_API_BASE_URL;

export const axiosInstance = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// --- token helpers (also used by AuthContext) ---
export function getStoredToken(): string | null {
  return localStorage.getItem(AUTH_TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  localStorage.setItem(AUTH_TOKEN_KEY, token);
}

export function clearStoredToken(): void {
  localStorage.removeItem(AUTH_TOKEN_KEY);
}

// --- request interceptor: attach Authorization header when a token exists ---
axiosInstance.interceptors.request.use((config) => {
  const token = getStoredToken();
  if (token) {
    config.headers = config.headers ?? {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/**
 * Listeners the AuthContext can register to be notified when the
 * response interceptor detects an unauthorized (401) response, so the
 * app can clear auth state and redirect to /login in one place.
 */
type UnauthorizedHandler = () => void;
let unauthorizedHandler: UnauthorizedHandler | null = null;

export function setUnauthorizedHandler(handler: UnauthorizedHandler): void {
  unauthorizedHandler = handler;
}

/** Global toast handler for network/5xx errors, registered by the app shell. */
type ToastHandler = (message: string) => void;
let toastHandler: ToastHandler | null = null;

export function setGlobalToastHandler(handler: ToastHandler): void {
  toastHandler = handler;
}

export function toApiErrorInfo(error: unknown): ApiErrorInfo {
  const axiosErr = error as AxiosError<ErrorResponse>;
  const data = axiosErr?.response?.data;
  if (data && typeof data === 'object' && 'message' in data) {
    return {
      message: data.message || 'Something went wrong. Please try again.',
      details: Array.isArray(data.details) ? data.details : [],
      status: axiosErr.response?.status,
    };
  }
  if (axiosErr?.message === 'Network Error' || !axiosErr?.response) {
    return {
      message: 'Unable to reach the server. Please check your connection and try again.',
      details: [],
    };
  }
  return {
    message: 'Something went wrong. Please try again.',
    details: [],
    status: axiosErr?.response?.status,
  };
}

// --- response interceptor ---
axiosInstance.interceptors.response.use(
  (response) => response,
  (error: AxiosError<ErrorResponse>) => {
    const status = error.response?.status;

    if (status === 401) {
      clearStoredToken();
      if (unauthorizedHandler) {
        unauthorizedHandler();
      } else {
        window.location.href = '/login';
      }
    } else if (!error.response || (status && status >= 500)) {
      // Network error or server error -> generic toast
      const info = toApiErrorInfo(error);
      if (toastHandler) {
        toastHandler(info.message);
      }
    }

    return Promise.reject(error);
  },
);

export default axiosInstance;
