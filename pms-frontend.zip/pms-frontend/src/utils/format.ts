const inrFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 2,
});

/** Formats a numeric amount as INR with thousands separators, e.g. ₹8,00,000.00 */
export function formatInr(value: number | string | undefined | null): string {
  if (value === undefined || value === null || value === '') return '—';
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (Number.isNaN(num)) return '—';
  return inrFormatter.format(num);
}

export function formatDate(value: string | undefined | null): string {
  if (!value) return '—';
  return value;
}
