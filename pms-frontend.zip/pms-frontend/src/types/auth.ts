export type Role = 'ADMIN' | 'CUSTOMER';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface TokenResponse {
  token: string;
}

/**
 * Shape of the decoded JWT payload. The backend puts the username in the
 * standard `sub` claim and the role in a custom `role` claim. We keep
 * `username` as an optional alias in case a future backend version adds it
 * directly to the payload.
 */
export interface DecodedToken {
  sub: string;
  username?: string;
  role: Role;
  iat: number;
  exp: number;
}

export interface AuthUser {
  username: string;
  role: Role;
}
