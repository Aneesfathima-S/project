import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { jwtDecode } from 'jwt-decode';
import { useNavigate } from 'react-router-dom';
import {
  clearStoredToken,
  getStoredToken,
  setStoredToken,
  setUnauthorizedHandler,
} from '../api/axiosInstance';
import { authApi } from '../api/authApi';
import type { AuthUser, DecodedToken, Role } from '../types/auth';

interface AuthContextValue {
  user: AuthUser | null;
  token: string | null;
  role: Role | null;
  isAuthenticated: boolean;
  isInitializing: boolean;
  loginCustomer: (username: string, password: string) => Promise<void>;
  loginAdmin: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function decodeUser(token: string): AuthUser | null {
  try {
    const decoded = jwtDecode<DecodedToken>(token);
    return {
      username: decoded.username ?? decoded.sub,
      role: decoded.role,
    };
  } catch {
    return null;
  }
}

function isExpired(token: string): boolean {
  try {
    const decoded = jwtDecode<DecodedToken>(token);
    if (!decoded.exp) return true;
    return decoded.exp * 1000 <= Date.now();
  } catch {
    return true;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const logoutTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const logout = useCallback(() => {
    clearStoredToken();
    setToken(null);
    setUser(null);
    if (logoutTimerRef.current) {
      clearTimeout(logoutTimerRef.current);
      logoutTimerRef.current = null;
    }
  }, []);

  const scheduleAutoLogout = useCallback(
    (jwt: string) => {
      if (logoutTimerRef.current) {
        clearTimeout(logoutTimerRef.current);
        logoutTimerRef.current = null;
      }
      try {
        const decoded = jwtDecode<DecodedToken>(jwt);
        const msUntilExpiry = decoded.exp * 1000 - Date.now();
        if (msUntilExpiry <= 0) {
          logout();
          navigate('/login', { replace: true });
          return;
        }
        logoutTimerRef.current = setTimeout(() => {
          logout();
          navigate('/login', { replace: true });
        }, msUntilExpiry);
      } catch {
        logout();
      }
    },
    [logout, navigate],
  );

  const applyToken = useCallback(
    (jwt: string) => {
      setStoredToken(jwt);
      setToken(jwt);
      setUser(decodeUser(jwt));
      scheduleAutoLogout(jwt);
    },
    [scheduleAutoLogout],
  );

  // On app load: check for an existing token and validate expiry.
  useEffect(() => {
    const existing = getStoredToken();
    if (existing && !isExpired(existing)) {
      setToken(existing);
      setUser(decodeUser(existing));
      scheduleAutoLogout(existing);
    } else if (existing) {
      clearStoredToken();
    }
    setIsInitializing(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Register the 401 handler so the axios response interceptor can clear
  // auth state and redirect through the router (rather than a hard reload).
  useEffect(() => {
    setUnauthorizedHandler(() => {
      logout();
      navigate('/login', { replace: true });
    });
  }, [logout, navigate]);

  const loginCustomer = useCallback(
    async (username: string, password: string) => {
      const { token: jwt } = await authApi.customerLogin({ username, password });
      applyToken(jwt);
    },
    [applyToken],
  );

  const loginAdmin = useCallback(
    async (username: string, password: string) => {
      const { token: jwt } = await authApi.adminLogin({ username, password });
      applyToken(jwt);
    },
    [applyToken],
  );

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      token,
      role: user?.role ?? null,
      isAuthenticated: !!token && !!user,
      isInitializing,
      loginCustomer,
      loginAdmin,
      logout,
    }),
    [user, token, isInitializing, loginCustomer, loginAdmin, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
}
