import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { policyApi } from '../api/policyApi';
import { toApiErrorInfo } from '../api/axiosInstance';
import PolicyTable from '../components/PolicyTable';
import PaginationBar from '../components/PaginationBar';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorAlert from '../components/ErrorAlert';
import type { ApiErrorInfo } from '../types/common';
import type { PolicySearchParams, PolicyType, SearchResponseDTO } from '../types/policy';
import { POLICY_TYPE_LABELS } from '../types/policy';

interface SearchFormValues {
  policyType: PolicyType | '';
  years: string;
  companyName: string;
  policyId: string;
  policyName: string;
}

const PAGE_SIZE = 10;

export default function PolicySearchPage() {
  const [result, setResult] = useState<SearchResponseDTO | null>(null);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ApiErrorInfo | null>(null);
  const [lastCriteria, setLastCriteria] = useState<PolicySearchParams | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SearchFormValues>({
    defaultValues: { policyType: '', years: '', companyName: '', policyId: '', policyName: '' },
  });

  const runSearch = async (criteria: PolicySearchParams, targetPage: number) => {
    setLoading(true);
    setError(null);
    try {
      const response = await policyApi.search({ ...criteria, page: targetPage, size: PAGE_SIZE });
      setResult(response);
      setPage(targetPage);
    } catch (err) {
      setError(toApiErrorInfo(err));
      setResult(null);
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (values: SearchFormValues) => {
    const criteria: PolicySearchParams = {
      ...(values.policyType ? { policyType: values.policyType } : {}),
      ...(values.years ? { years: Number(values.years) } : {}),
      ...(values.companyName ? { companyName: values.companyName } : {}),
      ...(values.policyId ? { policyId: values.policyId } : {}),
      ...(values.policyName ? { policyName: values.policyName } : {}),
    };
    if (Object.keys(criteria).length === 0) {
      setError({ message: 'Please provide at least one search criterion.', details: [] });
      setResult(null);
      return;
    }
    setLastCriteria(criteria);
    await runSearch(criteria, 0);
  };

  const handlePageChange = (targetPage: number) => {
    if (lastCriteria) {
      runSearch(lastCriteria, targetPage);
    }
  };

  return (
    <div>
      <h1 className="h3 mb-4">Search Policies</h1>

      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="row g-3">
              <div className="col-md-4">
                <label className="form-label">Policy Type</label>
                <select className="form-select" {...register('policyType')}>
                  <option value="">Any</option>
                  {Object.entries(POLICY_TYPE_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label">Years</label>
                <input
                  type="number"
                  min={1}
                  className={`form-control ${errors.years ? 'is-invalid' : ''}`}
                  {...register('years')}
                />
              </div>
              <div className="col-md-3">
                <label className="form-label">Company Name</label>
                <input className="form-control" {...register('companyName')} />
              </div>
              <div className="col-md-3">
                <label className="form-label">Policy ID</label>
                <input className="form-control" placeholder="HI-2026-001" {...register('policyId')} />
              </div>
              <div className="col-md-6">
                <label className="form-label">Policy Name</label>
                <input className="form-control" {...register('policyName')} />
              </div>
              <div className="col-md-6 d-flex align-items-end">
                <button type="submit" className="btn btn-primary w-100" disabled={loading}>
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" />
                      Searching…
                    </>
                  ) : (
                    'Search'
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <ErrorAlert error={error} onDismiss={() => setError(null)} />

      {loading && <LoadingSpinner label="Searching policies…" />}

      {!loading && result && (
        <>
          <div className="alert alert-info">{result.message}</div>
          <div className="card shadow-sm">
            <div className="card-body">
              <PolicyTable policies={result.policies} />
            </div>
          </div>
          <div className="mt-4">
            <PaginationBar currentPage={page} totalPages={result.totalPages} onPageChange={handlePageChange} />
          </div>
        </>
      )}
    </div>
  );
}
