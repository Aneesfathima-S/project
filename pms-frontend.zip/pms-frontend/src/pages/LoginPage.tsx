import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import ErrorAlert from '../components/ErrorAlert';
import { toApiErrorInfo } from '../api/axiosInstance';
import type { ApiErrorInfo } from '../types/common';
import type { Role } from '../types/auth';

interface LoginFormValues {
  username: string;
  password: string;
}

export default function LoginPage() {
  const [role, setRole] = useState<Role>('CUSTOMER');
  const [apiError, setApiError] = useState<ApiErrorInfo | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const { loginCustomer, loginAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>();

  const from = (location.state as { from?: { pathname: string } })?.from?.pathname;

  const onSubmit = async (values: LoginFormValues) => {
    setApiError(null);
    setSubmitting(true);
    try {
      if (role === 'ADMIN') {
        await loginAdmin(values.username, values.password);
        navigate(from ?? '/admin/dashboard', { replace: true });
      } else {
        await loginCustomer(values.username, values.password);
        navigate(from ?? '/policies', { replace: true });
      }
    } catch (err) {
      setApiError(toApiErrorInfo(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="row justify-content-center">
      <div className="col-12 col-md-6 col-lg-5">
        <div className="card shadow-sm">
          <div className="card-body p-4">
            <h2 className="h4 mb-3 text-center">Sign In</h2>

            <div className="btn-group w-100 mb-4" role="group" aria-label="Login role toggle">
              <button
                type="button"
                className={`btn ${role === 'CUSTOMER' ? 'btn-primary' : 'btn-outline-primary'}`}
                onClick={() => setRole('CUSTOMER')}
              >
                Customer
              </button>
              <button
                type="button"
                className={`btn ${role === 'ADMIN' ? 'btn-primary' : 'btn-outline-primary'}`}
                onClick={() => setRole('ADMIN')}
              >
                Admin
              </button>
            </div>

            <ErrorAlert error={apiError} onDismiss={() => setApiError(null)} />

            <form onSubmit={handleSubmit(onSubmit)} noValidate>
              <div className="mb-3">
                <label htmlFor="username" className="form-label">
                  {role === 'CUSTOMER' ? 'Email' : 'Username'}
                </label>
                <input
                  id="username"
                  type={role === 'CUSTOMER' ? 'email' : 'text'}
                  className={`form-control ${errors.username ? 'is-invalid' : ''}`}
                  placeholder={role === 'CUSTOMER' ? 'you@example.com' : 'admin'}
                  {...register('username', { required: 'This field is required' })}
                />
                {errors.username && <div className="invalid-feedback">{errors.username.message}</div>}
              </div>

              <div className="mb-4">
                <label htmlFor="password" className="form-label">
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                  {...register('password', { required: 'Password is required' })}
                />
                {errors.password && <div className="invalid-feedback">{errors.password.message}</div>}
              </div>

              <button type="submit" className="btn btn-primary w-100" disabled={submitting}>
                {submitting ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" />
                    Signing in…
                  </>
                ) : (
                  `Sign in as ${role === 'CUSTOMER' ? 'Customer' : 'Admin'}`
                )}
              </button>
            </form>

            {role === 'CUSTOMER' && (
              <p className="text-center mt-3 mb-0 small">
                Don&apos;t have an account?{' '}
                <a href="/register" onClick={(e) => { e.preventDefault(); navigate('/register'); }}>
                  Register here
                </a>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
