import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { policyApi } from '../api/policyApi';
import { toApiErrorInfo } from '../api/axiosInstance';
import ErrorAlert from '../components/ErrorAlert';
import { formatInr } from '../utils/format';
import type { ApiErrorInfo } from '../types/common';
import type { PolicyRequestDTO, PolicyResponseDTO, PolicyType } from '../types/policy';
import { POLICY_TYPE_LABELS, USER_TYPES } from '../types/policy';
import type { UserType } from '../types/customer';

interface PolicyFormValues {
  policyName: string;
  startDate: string;
  durationYears: number;
  companyName: string;
  initialDeposit: number;
  policyType: PolicyType;
  userTypes: UserType[];
  termsPerYear: number;
  termAmount: number;
  interest: number;
}

function todayIso(): string {
  return new Date().toISOString().split('T')[0];
}

export default function PolicyRegisterPage() {
  const [apiError, setApiError] = useState<ApiErrorInfo | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<PolicyResponseDTO | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<PolicyFormValues>({
    defaultValues: {
      policyType: 'HEALTH_INSURANCE',
      userTypes: [],
      termsPerYear: 12,
    },
  });

  const onSubmit = async (values: PolicyFormValues) => {
    setApiError(null);
    if (!values.userTypes || values.userTypes.length === 0) {
      setApiError({ message: 'At least one user type must be selected', details: [] });
      return;
    }
    setSubmitting(true);
    try {
      const payload: PolicyRequestDTO = {
        policyName: values.policyName,
        startDate: values.startDate,
        durationYears: Number(values.durationYears),
        companyName: values.companyName,
        initialDeposit: Number(values.initialDeposit),
        policyType: values.policyType,
        userTypes: values.userTypes,
        termsPerYear: Number(values.termsPerYear),
        termAmount: Number(values.termAmount),
        interest: Number(values.interest),
      };
      const response = await policyApi.register(payload);
      setResult(response);
      reset({ policyType: 'HEALTH_INSURANCE', userTypes: [], termsPerYear: 12 } as Partial<PolicyFormValues>);
    } catch (err) {
      setApiError(toApiErrorInfo(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <h1 className="h3 mb-4">Register a New Policy</h1>

      {result && (
        <div className="card border-success shadow-sm mb-4">
          <div className="card-body">
            <h2 className="h5 text-success">Policy Registered Successfully</h2>
            {/* Backend-provided HTML confirmation message */}
            <div dangerouslySetInnerHTML={{ __html: result.confirmationMessage }} />
            <div className="row mt-3">
              <div className="col-sm-4">
                <div className="text-muted small">Policy ID</div>
                <div className="fw-semibold">{result.policyId}</div>
              </div>
              <div className="col-sm-4">
                <div className="text-muted small">End Date</div>
                <div className="fw-semibold">{result.endDate}</div>
              </div>
              <div className="col-sm-4">
                <div className="text-muted small">Maturity Amount</div>
                <div className="fw-semibold">{formatInr(result.maturityAmount)}</div>
              </div>
            </div>
            <button className="btn btn-outline-success btn-sm mt-3" onClick={() => setResult(null)}>
              Register Another Policy
            </button>
          </div>
        </div>
      )}

      <div className="card shadow-sm">
        <div className="card-body">
          <ErrorAlert error={apiError} onDismiss={() => setApiError(null)} />

          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="row">
              <div className="col-md-6 mb-3">
                <label className="form-label">Policy Name</label>
                <input
                  className={`form-control ${errors.policyName ? 'is-invalid' : ''}`}
                  {...register('policyName', {
                    required: 'Policy name is mandatory',
                    maxLength: { value: 150, message: 'Must not exceed 150 characters' },
                  })}
                />
                {errors.policyName && <div className="invalid-feedback">{errors.policyName.message}</div>}
              </div>
              <div className="col-md-6 mb-3">
                <label className="form-label">Company Name</label>
                <input
                  className={`form-control ${errors.companyName ? 'is-invalid' : ''}`}
                  {...register('companyName', {
                    required: 'Company name is mandatory',
                    maxLength: { value: 150, message: 'Must not exceed 150 characters' },
                  })}
                />
                {errors.companyName && <div className="invalid-feedback">{errors.companyName.message}</div>}
              </div>
            </div>

            <div className="row">
              <div className="col-md-4 mb-3">
                <label className="form-label">Policy Type</label>
                <select className="form-select" {...register('policyType', { required: true })}>
                  {Object.entries(POLICY_TYPE_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-4 mb-3">
                <label className="form-label">Start Date</label>
                <input
                  type="date"
                  min={todayIso()}
                  className={`form-control ${errors.startDate ? 'is-invalid' : ''}`}
                  {...register('startDate', { required: 'Start date is mandatory' })}
                />
                {errors.startDate && <div className="invalid-feedback">{errors.startDate.message}</div>}
              </div>
              <div className="col-md-4 mb-3">
                <label className="form-label">Duration (years)</label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  className={`form-control ${errors.durationYears ? 'is-invalid' : ''}`}
                  {...register('durationYears', {
                    required: 'Duration is mandatory',
                    valueAsNumber: true,
                    min: { value: 1, message: 'Must be at least 1 year' },
                    max: { value: 100, message: 'Must not exceed 100 years' },
                  })}
                />
                {errors.durationYears && <div className="invalid-feedback">{errors.durationYears.message}</div>}
              </div>
            </div>

            <div className="row">
              <div className="col-md-4 mb-3">
                <label className="form-label">Initial Deposit (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  className={`form-control ${errors.initialDeposit ? 'is-invalid' : ''}`}
                  {...register('initialDeposit', {
                    required: 'Initial deposit is mandatory',
                    valueAsNumber: true,
                    validate: (v) => (v > 0 ? true : 'Must be greater than zero'),
                  })}
                />
                {errors.initialDeposit && <div className="invalid-feedback">{errors.initialDeposit.message}</div>}
              </div>
              <div className="col-md-4 mb-3">
                <label className="form-label">Terms Per Year</label>
                <input
                  type="number"
                  min={1}
                  className={`form-control ${errors.termsPerYear ? 'is-invalid' : ''}`}
                  {...register('termsPerYear', {
                    required: 'Terms per year is mandatory',
                    valueAsNumber: true,
                    min: { value: 1, message: 'Must be at least 1' },
                  })}
                />
                {errors.termsPerYear && <div className="invalid-feedback">{errors.termsPerYear.message}</div>}
              </div>
              <div className="col-md-4 mb-3">
                <label className="form-label">Term Amount (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  className={`form-control ${errors.termAmount ? 'is-invalid' : ''}`}
                  {...register('termAmount', {
                    required: 'Term amount is mandatory',
                    valueAsNumber: true,
                    validate: (v) => (v > 0 ? true : 'Must be greater than zero'),
                  })}
                />
                {errors.termAmount && <div className="invalid-feedback">{errors.termAmount.message}</div>}
              </div>
            </div>

            <div className="row">
              <div className="col-md-4 mb-3">
                <label className="form-label">Interest (%)</label>
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  className={`form-control ${errors.interest ? 'is-invalid' : ''}`}
                  {...register('interest', {
                    required: 'Interest is mandatory',
                    valueAsNumber: true,
                    min: { value: 0, message: 'Must not be negative' },
                  })}
                />
                {errors.interest && <div className="invalid-feedback">{errors.interest.message}</div>}
              </div>
              <div className="col-md-8 mb-3">
                <label className="form-label d-block">Eligible User Types</label>
                <div className="d-flex gap-3 flex-wrap">
                  {USER_TYPES.map((ut) => (
                    <div className="form-check" key={ut}>
                      <input
                        className="form-check-input"
                        type="checkbox"
                        value={ut}
                        id={`userType-${ut}`}
                        {...register('userTypes')}
                      />
                      <label className="form-check-label" htmlFor={`userType-${ut}`}>
                        {ut}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <button type="submit" className="btn btn-primary w-100 mt-2" disabled={submitting}>
              {submitting ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" />
                  Registering…
                </>
              ) : (
                'Register Policy'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
