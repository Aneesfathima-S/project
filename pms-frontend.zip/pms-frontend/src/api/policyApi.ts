import axiosInstance from './axiosInstance';
import type {
  PolicyPageResponseDTO,
  PolicyRequestDTO,
  PolicyResponseDTO,
  PolicySearchParams,
  SearchResponseDTO,
} from '../types/policy';

export const policyApi = {
  register: (payload: PolicyRequestDTO) =>
    axiosInstance
      .post<PolicyResponseDTO>('/api/v1.0/policy/register', payload)
      .then((res) => res.data),

  getAll: (page: number, size: number) =>
    axiosInstance
      .get<PolicyPageResponseDTO>('/api/v1.0/policy/getall', {
        params: { page, size },
      })
      .then((res) => res.data),

  search: (params: PolicySearchParams) =>
    axiosInstance
      .get<SearchResponseDTO>('/api/v1.0/policy/searches', {
        params,
      })
      .then((res) => res.data),
};
