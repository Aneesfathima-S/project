import type { PolicyResponseDTO } from '../types/policy';
import { POLICY_TYPE_LABELS } from '../types/policy';
import { formatInr } from '../utils/format';

interface PolicyTableProps {
  policies: PolicyResponseDTO[];
  emptyMessage?: string;
}

export default function PolicyTable({ policies, emptyMessage = 'No policies found.' }: PolicyTableProps) {
  if (policies.length === 0) {
    return <div className="text-center text-muted py-4">{emptyMessage}</div>;
  }

  return (
    <div className="table-responsive">
      <table className="table table-striped table-hover align-middle">
        <thead className="table-dark">
          <tr>
            <th>Policy ID</th>
            <th>Name</th>
            <th>Type</th>
            <th>Company</th>
            <th>Start</th>
            <th>End</th>
            <th>Duration</th>
            <th>User Types</th>
            <th className="text-end">Initial Deposit</th>
            <th className="text-end">Term Amount</th>
            <th className="text-end">Interest</th>
            <th className="text-end">Maturity Amount</th>
          </tr>
        </thead>
        <tbody>
          {policies.map((p) => (
            <tr key={p.policyId}>
              <td>
                <span className="badge text-bg-secondary">{p.policyId}</span>
              </td>
              <td>{p.policyName}</td>
              <td>
                <span className="badge text-bg-info text-dark">
                  {POLICY_TYPE_LABELS[p.policyType] ?? p.policyType}
                </span>
              </td>
              <td>{p.companyName}</td>
              <td>{p.startDate}</td>
              <td>{p.endDate}</td>
              <td>{p.durationYears} yr(s)</td>
              <td>
                {p.userTypes.map((ut) => (
                  <span key={ut} className="badge text-bg-light text-dark border me-1">
                    {ut}
                  </span>
                ))}
              </td>
              <td className="text-end">{formatInr(p.initialDeposit)}</td>
              <td className="text-end">{formatInr(p.termAmount)}</td>
              <td className="text-end">{p.interest}%</td>
              <td className="text-end fw-semibold">{formatInr(p.maturityAmount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
