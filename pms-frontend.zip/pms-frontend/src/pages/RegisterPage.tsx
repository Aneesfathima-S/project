import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { customerApi } from '../api/customerApi';
import { toApiErrorInfo } from '../api/axiosInstance';
import ErrorAlert from '../components/ErrorAlert';
import type { ApiErrorInfo } from '../types/common';
import type { CustomerRequestDTO, CustomerResponseDTO, EmployerType } from '../types/customer';

interface RegisterFormValues {
  firstName: string;
  lastName: string;
  dob: string;
  address: string;
  contactNo: string;
  email: string;
  password: string;
  confirmPassword: string;
  salary: number;
  panNo: string;
  employerType: EmployerType;
  employerName?: string;
}

const PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
const PHONE_REGEX = /^[0-9]{10}$/;

function todayIso(): string {
  return new Date().toISOString().split('T')[0];
}

export default function RegisterPage() {
  const [apiError, setApiError] = useState<ApiErrorInfo | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<CustomerResponseDTO | null>(null);
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<RegisterFormValues>({
    defaultValues: { employerType: 'SALARIED' },
  });

  const employerType = watch('employerType');
  const password = watch('password');

  const onSubmit = async (values: RegisterFormValues) => {
    setApiError(null);
    setSubmitting(true);
    try {
      const payload: CustomerRequestDTO = {
        firstName: values.firstName,
        lastName: values.lastName,
        dob: values.dob,
        address: values.address,
        contactNo: values.contactNo,
        email: values.email,
        password: values.password,
        salary: Number(values.salary),
        panNo: values.panNo.toUpperCase(),
        employerType: values.employerType,
        ...(values.employerType === 'SALARIED' ? { employerName: values.employerName } : {}),
      };
      const response = await customerApi.register(payload);
      setResult(response);
    } catch (err) {
      setApiError(toApiErrorInfo(err));
    } finally {
      setSubmitting(false);
    }
  };

  if (result) {
    return (
      <div className="row justify-content-center">
        <div className="col-12 col-md-8 col-lg-6">
          <div className="card shadow-sm border-success">
            <div className="card-body p-4 text-center">
              <h2 className="h4 text-success mb-3">Registration Successful 🎉</h2>
              <p>
                Welcome, <strong>{result.firstName} {result.lastName}</strong>! Your account has been created.
              </p>
              <p className="mb-1">
                Assigned customer category:{' '}
                <span className="badge text-bg-primary fs-6">{result.userType}</span>
              </p>
              <p className="text-muted small">
                You can now log in using your email and password.
              </p>
              <button className="btn btn-primary mt-2" onClick={() => navigate('/login')}>
                Go to Login
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="row justify-content-center">
      <div className="col-12 col-lg-8">
        <div className="card shadow-sm">
          <div className="card-body p-4">
            <h2 className="h4 mb-4 text-center">Create Your Account</h2>

            <ErrorAlert error={apiError} onDismiss={() => setApiError(null)} />

            <form onSubmit={handleSubmit(onSubmit)} noValidate>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label">First Name</label>
                  <input
                    className={`form-control ${errors.firstName ? 'is-invalid' : ''}`}
                    {...register('firstName', {
                      required: 'First name is mandatory',
                      maxLength: { value: 100, message: 'Must not exceed 100 characters' },
                    })}
                  />
                  {errors.firstName && <div className="invalid-feedback">{errors.firstName.message}</div>}
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label">Last Name</label>
                  <input
                    className={`form-control ${errors.lastName ? 'is-invalid' : ''}`}
                    {...register('lastName', {
                      required: 'Last name is mandatory',
                      maxLength: { value: 100, message: 'Must not exceed 100 characters' },
                    })}
                  />
                  {errors.lastName && <div className="invalid-feedback">{errors.lastName.message}</div>}
                </div>
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label">Date of Birth</label>
                  <input
                    type="date"
                    max={todayIso()}
                    className={`form-control ${errors.dob ? 'is-invalid' : ''}`}
                    {...register('dob', {
                      required: 'Date of birth is mandatory',
                      validate: (v) =>
                        new Date(v) < new Date() || 'Date of birth must be in the past',
                    })}
                  />
                  {errors.dob && <div className="invalid-feedback">{errors.dob.message}</div>}
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label">Contact Number</label>
                  <input
                    className={`form-control ${errors.contactNo ? 'is-invalid' : ''}`}
                    placeholder="9876543210"
                    {...register('contactNo', {
                      required: 'Contact number is mandatory',
                      pattern: { value: PHONE_REGEX, message: 'Must be a valid 10-digit number' },
                    })}
                  />
                  {errors.contactNo && <div className="invalid-feedback">{errors.contactNo.message}</div>}
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label">Address</label>
                <textarea
                  className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                  rows={2}
                  {...register('address', {
                    required: 'Address is mandatory',
                    maxLength: { value: 255, message: 'Must not exceed 255 characters' },
                  })}
                />
                {errors.address && <div className="invalid-feedback">{errors.address.message}</div>}
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label">Email</label>
                  <input
                    type="email"
                    className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                    placeholder="you@example.com"
                    {...register('email', {
                      required: 'Email is mandatory',
                      pattern: { value: /^\S+@\S+\.\S+$/, message: 'Email must be valid' },
                      maxLength: { value: 150, message: 'Must not exceed 150 characters' },
                    })}
                  />
                  {errors.email && <div className="invalid-feedback">{errors.email.message}</div>}
                  <div className="form-text">This will be your login username.</div>
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label">PAN Number</label>
                  <input
                    className={`form-control ${errors.panNo ? 'is-invalid' : ''}`}
                    placeholder="ABCDE1234F"
                    style={{ textTransform: 'uppercase' }}
                    {...register('panNo', {
                      required: 'PAN number is mandatory',
                      pattern: { value: PAN_REGEX, message: 'Must be in valid format e.g. ABCDE1234F' },
                    })}
                  />
                  {errors.panNo && <div className="invalid-feedback">{errors.panNo.message}</div>}
                </div>
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label">Password</label>
                  <input
                    type="password"
                    className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                    {...register('password', {
                      required: 'Password is mandatory',
                      minLength: { value: 6, message: 'Must be at least 6 characters' },
                      maxLength: { value: 100, message: 'Must not exceed 100 characters' },
                    })}
                  />
                  {errors.password && <div className="invalid-feedback">{errors.password.message}</div>}
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label">Confirm Password</label>
                  <input
                    type="password"
                    className={`form-control ${errors.confirmPassword ? 'is-invalid' : ''}`}
                    {...register('confirmPassword', {
                      required: 'Please confirm your password',
                      validate: (v) => v === password || 'Passwords do not match',
                    })}
                  />
                  {errors.confirmPassword && (
                    <div className="invalid-feedback">{errors.confirmPassword.message}</div>
                  )}
                </div>
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label">Annual Salary (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    className={`form-control ${errors.salary ? 'is-invalid' : ''}`}
                    {...register('salary', {
                      required: 'Salary is mandatory',
                      valueAsNumber: true,
                      validate: (v) => (v > 0 ? true : 'Salary must be greater than zero'),
                    })}
                  />
                  {errors.salary && <div className="invalid-feedback">{errors.salary.message}</div>}
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label">Employer Type</label>
                  <select
                    className={`form-select ${errors.employerType ? 'is-invalid' : ''}`}
                    {...register('employerType', { required: true })}
                  >
                    <option value="SALARIED">Salaried</option>
                    <option value="SELF_EMPLOYED">Self Employed</option>
                  </select>
                </div>
              </div>

              {employerType === 'SALARIED' && (
                <div className="mb-3">
                  <label className="form-label">Employer Name</label>
                  <input
                    className={`form-control ${errors.employerName ? 'is-invalid' : ''}`}
                    {...register('employerName', {
                      required: employerType === 'SALARIED' ? 'Employer name is required for salaried employees' : false,
                      maxLength: { value: 150, message: 'Must not exceed 150 characters' },
                    })}
                  />
                  {errors.employerName && <div className="invalid-feedback">{errors.employerName.message}</div>}
                </div>
              )}

              <button type="submit" className="btn btn-primary w-100 mt-2" disabled={submitting}>
                {submitting ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" />
                    Creating account…
                  </>
                ) : (
                  'Register'
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
