import axiosInstance from './axiosInstance';
import type { LoginRequest, TokenResponse } from '../types/auth';

export const authApi = {
  customerLogin: (payload: LoginRequest) =>
    axiosInstance
      .post<TokenResponse>('/api/v1.0/auth/customer/login', payload)
      .then((res) => res.data),

  adminLogin: (payload: LoginRequest) =>
    axiosInstance
      .post<TokenResponse>('/api/v1.0/auth/admin/login', payload)
      .then((res) => res.data),
};
