interface LoadingSpinnerProps {
  label?: string;
  fullPage?: boolean;
}

export default function LoadingSpinner({ label = 'Loading…', fullPage = true }: LoadingSpinnerProps) {
  return (
    <div
      className={`d-flex flex-column align-items-center justify-content-center gap-2 ${
        fullPage ? 'py-5' : 'py-3'
      }`}
    >
      <div className="spinner-border text-primary" role="status">
        <span className="visually-hidden">{label}</span>
      </div>
      <span className="text-muted small">{label}</span>
    </div>
  );
}
