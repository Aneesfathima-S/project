export type EmployerType = 'SALARIED' | 'SELF_EMPLOYED';

export type UserType = 'A' | 'B' | 'C' | 'D' | 'E';

export interface CustomerRequestDTO {
  firstName: string;
  lastName: string;
  dob: string; // yyyy-MM-dd
  address: string;
  contactNo: string;
  email: string;
  password: string;
  salary: number;
  panNo: string;
  employerType: EmployerType;
  employerName?: string;
}

export interface CustomerResponseDTO {
  customerId: number;
  firstName: string;
  lastName: string;
  dob: string;
  address: string;
  contactNo: string;
  email: string;
  salary: number;
  panNo: string;
  employerType: EmployerType;
  employerName?: string;
  userType: UserType;
}
